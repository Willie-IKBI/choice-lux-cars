import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:choice_lux_cars/app/theme.dart';
import 'package:choice_lux_cars/shared/utils/snackbar_utils.dart';
import 'package:choice_lux_cars/features/jobs/providers/jobs_provider.dart';
import 'package:choice_lux_cars/features/auth/providers/auth_provider.dart';
import 'package:choice_lux_cars/core/services/supabase_service.dart';
import 'package:choice_lux_cars/features/jobs/models/job.dart';
import 'package:choice_lux_cars/features/jobs/models/trip.dart';
import 'package:choice_lux_cars/shared/widgets/luxury_app_bar.dart';
import 'package:choice_lux_cars/shared/utils/driver_flow_utils.dart';
import 'package:choice_lux_cars/features/jobs/services/driver_flow_api_service.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class JobSummaryScreen extends ConsumerStatefulWidget {
  final String jobId;
  
  const JobSummaryScreen({
    super.key,
    required this.jobId,
  });

  @override
  ConsumerState<JobSummaryScreen> createState() => _JobSummaryScreenState();
}

class _JobSummaryScreenState extends ConsumerState<JobSummaryScreen> {
  bool _isLoading = true;
  bool _isConfirming = false; // Prevent duplicate confirmation calls
  String? _errorMessage;
  Job? _job;
  List<Trip> _trips = []; // Changed from List<Trip> to List<dynamic>
  dynamic _client;
  dynamic _agent;
  dynamic _vehicle;
  dynamic _driver;
  
  // Step completion times
  Map<String, dynamic>? _driverFlowData;
  List<Map<String, dynamic>> _tripProgressData = [];
  
  // Mobile accordion state
  final Map<String, bool> _expandedSections = {
    'jobDetails': true,
    'clientAgent': true,
    'vehicleDriver': true,
    'payment': true,
    'trips': true,
    'stepTimeline': true, // New section for step timeline
  };
  
  @override
  void initState() {
    super.initState();
    _loadJobData();
  }
  
  Future<void> _loadJobData() async {
    setState(() => _isLoading = true);
    
    try {
      // Try to find job in local state first
      final jobs = ref.read(jobsProvider);
      Job? job;
      
      job = jobs.when(
        data: (jobsList) => jobsList.firstWhere((job) => job.id == widget.jobId),
        loading: () => null,
        error: (err, stack) => null,
      );
      
      if (job == null) {
        print('Job ${widget.jobId} not found in local state, fetching from database...');
        // If not found locally, fetch from database
        job = await ref.read(jobsProvider.notifier).fetchJobById(widget.jobId);
        if (job == null) {
          print('Job ${widget.jobId} not found in database');
          _errorMessage = 'Job not found';
          setState(() => _isLoading = false);
          return;
        }
      }
      
      _job = job;
      
      // Load trips for this job using the tripsProvider
      print('Loading trips for job ${widget.jobId}...');
      await ref.read(tripsProvider(int.parse(widget.jobId)).notifier).fetchTripsForJob(widget.jobId.toString());
      final trips = ref.read(tripsProvider(int.parse(widget.jobId)));
      _trips = trips;
      print('Loaded ${trips.length} trips for job ${widget.jobId}');
      
      // Load step completion times
      await _loadStepCompletionData();
      
      // Load related entities from database directly
      await _loadRelatedEntities();
      
    } catch (e) {
      print('Error loading job data: $e');
      // Store error to show in build method
      _errorMessage = 'Error loading job data: $e';
    } finally {
      setState(() => _isLoading = false);
    }
  }
  
  Future<void> _loadRelatedEntities() async {
    try {
      // Load client data
      if (_job!.clientId.isNotEmpty) {
        final clientResponse = await Supabase.instance.client
            .from('clients')
            .select('*')
            .eq('id', int.parse(_job!.clientId))
            .maybeSingle();
        _client = clientResponse;
      }
      
      // Load vehicle data
      if (_job!.vehicleId.isNotEmpty) {
        final vehicleResponse = await Supabase.instance.client
            .from('vehicles')
            .select('*')
            .eq('id', int.parse(_job!.vehicleId))
            .maybeSingle();
        _vehicle = vehicleResponse;
      }
      
      // Load driver data
      if (_job!.driverId.isNotEmpty) {
        final driverResponse = await Supabase.instance.client
            .from('profiles')
            .select('*')
            .eq('id', _job!.driverId)
            .maybeSingle();
        _driver = driverResponse;
      }
      
      print('Loaded related entities:');
      print('Client: ${_client != null ? 'Found' : 'Not found'}');
      print('Vehicle: ${_vehicle != null ? 'Found' : 'Not found'}');
      print('Driver: ${_driver != null ? 'Found' : 'Not found'}');
    } catch (e) {
      print('Error loading related entities: $e');
      // Don't fail the entire load if this fails
    }
  }
  
  Future<void> _loadStepCompletionData() async {
    try {
      // Load driver flow data
      final driverFlowResponse = await Supabase.instance.client
          .from('driver_flow')
          .select('*')
          .eq('job_id', int.parse(widget.jobId))
          .maybeSingle();
      
      _driverFlowData = driverFlowResponse;
      
      // Load trip progress data
      final tripProgressResponse = await Supabase.instance.client
          .from('trip_progress')
          .select('*')
          .eq('job_id', int.parse(widget.jobId))
          .order('trip_index');
      
      _tripProgressData = List<Map<String, dynamic>>.from(tripProgressResponse);
      
      print('Loaded step completion data:');
      print('Driver flow: $_driverFlowData');
      print('Trip progress: $_tripProgressData');
    } catch (e) {
      print('Error loading step completion data: $e');
      // Don't fail the entire load if this fails
    }
  }
  
  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }
    
    if (_errorMessage != null) {
      return Scaffold(
        appBar: LuxuryAppBar(
          title: 'Job Summary',
          showBackButton: true,
          onBackPressed: () => context.go('/jobs'),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, size: 64, color: Colors.red),
              const SizedBox(height: 16),
              Text(
                _errorMessage!,
                style: Theme.of(context).textTheme.bodyLarge,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    _isLoading = true;
                    _errorMessage = null;
                  });
                  _loadJobData();
                },
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    }
    
    if (_job == null) {
      return Scaffold(
        appBar: LuxuryAppBar(
          title: 'Job Summary',
          showBackButton: true,
          onBackPressed: () => context.go('/jobs'),
        ),
        body: const Center(
          child: Text('Job not found'),
        ),
      );
    }
    
    // Calculate total amount from job payment amount since trips are not implemented
    final totalAmount = _job!.paymentAmount ?? 0.0;
    final isDesktop = MediaQuery.of(context).size.width > 768;
    
    return Scaffold(
      appBar: LuxuryAppBar(
        title: 'Job Summary',
        subtitle: 'Job #${_job!.id}',
        showBackButton: true,
        onBackPressed: () => context.go('/jobs'),
        actions: [
          IconButton(
            icon: const Icon(Icons.print),
            onPressed: () => _printJobSummary(),
            tooltip: 'Print Summary',
          ),
          IconButton(
            icon: const Icon(Icons.share),
            onPressed: () => _shareJobSummary(),
            tooltip: 'Share Summary',
          ),
        ],
      ),
      body: isDesktop ? _buildDesktopLayout(totalAmount) : _buildMobileLayout(totalAmount),
    );
  }
  
  Widget _buildDesktopLayout(double totalAmount) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Left Column - Job Details, Client & Agent, Vehicle & Driver
        Expanded(
          flex: 1,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                _buildStatusCard(),
                const SizedBox(height: 24),
                _buildJobDetailsCard(),
                const SizedBox(height: 24),
                _buildClientAgentCard(),
                const SizedBox(height: 24),
                _buildVehicleDriverCard(),
                const SizedBox(height: 24),
                _buildPaymentCard(),
                const SizedBox(height: 24),
                _buildStepTimelineCard(),
                if (_job!.notes != null && _job!.notes!.isNotEmpty) ...[
                  const SizedBox(height: 24),
                  _buildNotesCard(),
                ],
              ],
            ),
          ),
        ),
        
        // Right Column - Trips Summary and Details
        Expanded(
          flex: 1,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                _buildTripsSummaryCard(totalAmount),
                const SizedBox(height: 24),
                if (_trips.isNotEmpty) _buildTripsListCard(),
                const SizedBox(height: 32),
                _buildActionButtons(),
              ],
            ),
          ),
        ),
      ],
    );
  }
  
  Widget _buildMobileLayout(double totalAmount) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildStatusCard(),
          const SizedBox(height: 16),
          _buildAccordionSection(
            'Job Details',
            'jobDetails',
            _buildJobDetailsContent(),
            Icons.work,
          ),
          const SizedBox(height: 16),
          _buildAccordionSection(
            'Client & Agent',
            'clientAgent',
            _buildClientAgentContent(),
            Icons.person,
          ),
          const SizedBox(height: 16),
          _buildAccordionSection(
            'Vehicle & Driver',
            'vehicleDriver',
            _buildVehicleDriverContent(),
            Icons.directions_car,
          ),
          const SizedBox(height: 16),
          _buildAccordionSection(
            'Payment',
            'payment',
            _buildPaymentContent(),
            Icons.payment,
          ),
          const SizedBox(height: 16),
          _buildAccordionSection(
            'Step Timeline',
            'stepTimeline',
            _buildStepTimelineContent(),
            Icons.timeline,
          ),
          if (_job!.notes != null && _job!.notes!.isNotEmpty) ...[
            const SizedBox(height: 16),
            _buildAccordionSection(
              'Notes',
              'notes',
              _buildNotesContent(),
              Icons.note,
            ),
          ],
          const SizedBox(height: 16),
                     _buildAccordionSection(
             'Trips Summary',
             'trips',
             _buildTripsContent(totalAmount),
             Icons.route,
           ),
           const SizedBox(height: 24),
           _buildMobileActionButtons(),
           const SizedBox(height: 24),
        ],
      ),
    );
  }
  
  Widget _buildAccordionSection(String title, String key, Widget content, IconData icon) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ExpansionTile(
        key: Key(key),
        initiallyExpanded: _expandedSections[key] ?? true,
        onExpansionChanged: (expanded) {
          setState(() {
            _expandedSections[key] = expanded;
          });
        },
        leading: Icon(icon, color: ChoiceLuxTheme.richGold),
        title: Text(
          title,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: content,
          ),
        ],
      ),
    );
  }
  
  Widget _buildStatusCard() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              _getStatusColor().withOpacity(0.1),
              _getStatusColor().withOpacity(0.05),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _getStatusColor().withOpacity(0.3)),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _getStatusColor(),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                Icons.work,
                color: Colors.white,
                size: 28,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _getStatusText(_job!.status),
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: _getStatusColor(),
                    ),
                  ),
                  Text(
                    'Job #${_job!.id}',
                    style: const TextStyle(
                      fontSize: 14,
                      color: Colors.grey,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: _getStatusColor(),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: _getStatusColor().withOpacity(0.3),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Text(
                _job!.daysUntilStartText,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildJobDetailsCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader('Job Details', Icons.work),
            const SizedBox(height: 16),
            _buildJobDetailsContent(),
          ],
        ),
      ),
    );
  }
  
  Widget _buildJobDetailsContent() {
    return Column(
      children: [
        _buildDetailRow('Job ID', _job!.id, Icons.tag),
        _buildDetailRow('Status', _getStatusText(_job!.status), Icons.info),
        _buildDetailRow('Job Start Date', _formatDate(_job!.jobStartDate), Icons.calendar_today),
        _buildDetailRow('Order Date', _formatDate(_job!.orderDate), Icons.schedule),
        _buildDetailRow('Days Until Start', _job!.daysUntilStartText, Icons.timer),
      ],
    );
  }
  
  Widget _buildClientAgentCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader('Client & Agent', Icons.person),
            const SizedBox(height: 16),
            _buildClientAgentContent(),
          ],
        ),
      ),
    );
  }
  
  Widget _buildClientAgentContent() {
    return Column(
      children: [
        _buildDetailRow('Client', _client?['company_name'] ?? 'Unknown', Icons.business),
        if (_agent != null)
          _buildDetailRow('Agent', _agent['agent_name'] ?? 'Unknown', Icons.person_outline),
        _buildDetailRow('Passenger Name', _job!.passengerName ?? 'Not provided', Icons.person),
        _buildDetailRow('Contact Number', _job!.passengerContact ?? 'Not provided', Icons.phone),
        if (!_job!.hasCompletePassengerDetails)
          Container(
            margin: const EdgeInsets.only(top: 12),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: ChoiceLuxTheme.errorColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: ChoiceLuxTheme.errorColor.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                Icon(Icons.warning, color: ChoiceLuxTheme.errorColor, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Passenger details incomplete',
                    style: TextStyle(
                      color: ChoiceLuxTheme.errorColor,
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                    ),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }
  
  Widget _buildVehicleDriverCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader('Vehicle & Driver', Icons.directions_car),
            const SizedBox(height: 16),
            _buildVehicleDriverContent(),
          ],
        ),
      ),
    );
  }
  
  Widget _buildVehicleDriverContent() {
    return Column(
      children: [
        _buildDetailRow('Vehicle', '${_vehicle?['make'] ?? ''} ${_vehicle?['model'] ?? ''}'.trim().isEmpty ? 'Unknown' : '${_vehicle?['make'] ?? ''} ${_vehicle?['model'] ?? ''}'.trim(), Icons.directions_car),
        _buildDetailRow('Registration', _vehicle?['reg_plate'] ?? 'Unknown', Icons.confirmation_number),
        _buildDetailRow('Driver', _driver?['display_name'] ?? 'Unknown', Icons.person),
        _buildDetailRow('Passengers', _formatPassengerCount(_job!.pasCount), Icons.people),
        _buildDetailRow('Luggage', _formatLuggageCount(_job!.luggageCount), Icons.work),
      ],
    );
  }
  
  Widget _buildPaymentCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader('Payment', Icons.payment),
            const SizedBox(height: 16),
            _buildPaymentContent(),
          ],
        ),
      ),
    );
  }
  
  Widget _buildPaymentContent() {
    return Column(
      children: [
        _buildDetailRow('Collect Payment', _job!.collectPayment ? 'Yes' : 'No', Icons.payment),
        if (_job!.collectPayment && _job!.paymentAmount != null)
          Container(
            margin: const EdgeInsets.only(top: 8),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: ChoiceLuxTheme.richGold.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: ChoiceLuxTheme.richGold.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                Icon(Icons.attach_money, color: ChoiceLuxTheme.richGold, size: 20),
                const SizedBox(width: 8),
                Text(
                  'Amount to Collect: R${_job!.paymentAmount!.toStringAsFixed(2)}',
                  style: TextStyle(
                    color: ChoiceLuxTheme.richGold,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }
  
  Widget _buildStepTimelineCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader('Step Timeline', Icons.timeline),
            const SizedBox(height: 16),
            FutureBuilder<List<Map<String, dynamic>>>(
              future: _getStepTimeline(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.all(16.0),
                      child: CircularProgressIndicator(),
                    ),
                  );
                }
                
                if (snapshot.hasError) {
                  return Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.red.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.red.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.error_outline,
                          color: Colors.red[600],
                          size: 20,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'Error loading timeline: ${snapshot.error}',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.red[600],
                              fontStyle: FontStyle.italic,
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                }
                
                final steps = snapshot.data ?? [];
                
                if (steps.isEmpty) {
                  return Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.grey.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.info_outline,
                          color: Colors.grey[600],
                          size: 20,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'Job not started yet. The timeline will show all steps including current progress once the job begins.',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey[600],
                              fontStyle: FontStyle.italic,
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                }
                
                return Column(
                  children: steps.map((step) {
                    return _buildStepTimelineItem(step);
                  }).toList(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStepTimelineItem(Map<String, dynamic> step) {
    final isTotal = step['isTotal'] == true;
    final status = step['status'] ?? 'completed'; // Default to completed for backward compatibility
    final isCompleted = status == 'completed';
    final isCurrent = status == 'current';
    final isUpcoming = status == 'upcoming';
    
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: isTotal 
                ? Colors.indigo.withOpacity(0.2)
                : isCurrent
                  ? ChoiceLuxTheme.richGold.withOpacity(0.2)
                  : isCompleted
                    ? ChoiceLuxTheme.successColor.withOpacity(0.2)
                    : Colors.grey.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: isTotal 
                  ? Colors.indigo.withOpacity(0.5)
                  : isCurrent
                    ? ChoiceLuxTheme.richGold.withOpacity(0.5)
                    : isCompleted
                      ? ChoiceLuxTheme.successColor.withOpacity(0.5)
                      : Colors.grey.withOpacity(0.3),
                width: isTotal || isCurrent ? 2 : 1,
              ),
            ),
            child: Icon(
              step['icon'],
              color: isTotal 
                ? Colors.indigo
                : isCurrent
                  ? ChoiceLuxTheme.richGold
                  : isCompleted
                    ? ChoiceLuxTheme.successColor
                    : Colors.grey,
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        step['title'],
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: isTotal ? FontWeight.w700 : FontWeight.bold,
                          color: isTotal 
                            ? Colors.indigo
                            : isCurrent
                              ? ChoiceLuxTheme.richGold
                              : isCompleted
                                ? Colors.black
                                : Colors.grey,
                        ),
                      ),
                    ),
                    if (isCurrent) ...[
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: step['status'] == 'not_started' 
                              ? ChoiceLuxTheme.infoColor 
                              : ChoiceLuxTheme.richGold,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          step['status'] == 'not_started' ? 'Not Started' : 'In Progress',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
                Text(
                  step['description'],
                  style: TextStyle(
                    fontSize: 14,
                    color: isUpcoming ? Colors.grey.withOpacity(0.7) : Colors.grey,
                  ),
                ),
                if (step['address'] != null)
                  Container(
                    margin: const EdgeInsets.only(top: 4),
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: isCurrent
                        ? ChoiceLuxTheme.richGold.withOpacity(0.1)
                        : Colors.blue.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(4),
                      border: Border.all(
                        color: isCurrent
                          ? ChoiceLuxTheme.richGold.withOpacity(0.3)
                          : Colors.blue.withOpacity(0.3),
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.location_on,
                          size: 12,
                          color: isCurrent
                            ? ChoiceLuxTheme.richGold
                            : Colors.blue,
                        ),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            step['address']!,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                              color: isCurrent
                                ? ChoiceLuxTheme.richGold
                                : Colors.blue,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                if (step['odometer'] != null)
                  Container(
                    margin: const EdgeInsets.only(top: 4),
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: isTotal 
                        ? Colors.indigo.withOpacity(0.1)
                        : Colors.grey.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(4),
                      border: Border.all(
                        color: isTotal 
                          ? Colors.indigo.withOpacity(0.3)
                          : Colors.grey.withOpacity(0.3),
                      ),
                    ),
                    child: Text(
                      step['odometer']!,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: isTotal ? Colors.indigo : Colors.grey[700],
                      ),
                    ),
                  ),
                if (isCurrent && step['progressPercentage'] != null)
                  Container(
                    margin: const EdgeInsets.only(top: 8),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Progress',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: ChoiceLuxTheme.richGold,
                              ),
                            ),
                            Text(
                              '${step['progressPercentage'].toInt()}%',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: ChoiceLuxTheme.richGold,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        LinearProgressIndicator(
                          value: step['progressPercentage'] / 100.0,
                          backgroundColor: ChoiceLuxTheme.richGold.withOpacity(0.2),
                          valueColor: AlwaysStoppedAnimation<Color>(ChoiceLuxTheme.richGold),
                          minHeight: 4,
                        ),
                      ],
                    ),
                  ),
                if (step['completedAt'] != null)
                  Text(
                    'Completed on: ${_formatDateTime(step['completedAt'])}',
                    style: const TextStyle(
                      fontSize: 12,
                      color: Colors.green,
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildNotesCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader('Notes', Icons.note),
            const SizedBox(height: 16),
            _buildNotesContent(),
          ],
        ),
      ),
    );
  }
  
  Widget _buildStepTimelineContent() {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _getStepTimeline(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: Padding(
              padding: EdgeInsets.all(16.0),
              child: CircularProgressIndicator(),
            ),
          );
        }
        
        if (snapshot.hasError) {
          return Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.red.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.red.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.error_outline,
                  color: Colors.red[600],
                  size: 20,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Error loading timeline: ${snapshot.error}',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.red[600],
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ),
              ],
            ),
          );
        }
        
        final steps = snapshot.data ?? [];
        
        if (steps.isEmpty) {
          return Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.grey.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.grey.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.info_outline,
                  color: Colors.grey[600],
                  size: 20,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'No steps have been completed yet. The timeline will show completed steps as the job progresses.',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ),
              ],
            ),
          );
        }
        
        return Column(
          children: steps.map((step) {
            return _buildStepTimelineItem(step);
          }).toList(),
        );
      },
    );
  }

  Widget _buildNotesContent() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey.withOpacity(0.2)),
      ),
      child: Text(
        _job!.notes!,
        style: const TextStyle(
          fontSize: 14,
          height: 1.5,
        ),
      ),
    );
  }
  
  Widget _buildTripsSummaryCard(double totalAmount) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader('Trips Summary', Icons.route),
            const SizedBox(height: 16),
            _buildTripsContent(totalAmount),
          ],
        ),
      ),
    );
  }
  
  Widget _buildTripsContent(double totalAmount) {
    return Column(
      children: [
        _buildDetailRow('Total Trips', '${_trips.length}', Icons.route),
        Container(
          margin: const EdgeInsets.only(top: 8),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: ChoiceLuxTheme.richGold.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: ChoiceLuxTheme.richGold.withOpacity(0.3)),
          ),
          child: Row(
            children: [
              Icon(Icons.attach_money, color: ChoiceLuxTheme.richGold, size: 24),
              const SizedBox(width: 12),
              Text(
                'Total Amount: R${totalAmount.toStringAsFixed(2)}',
                style: TextStyle(
                  color: ChoiceLuxTheme.richGold,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
  
  Widget _buildTripsListCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader('Trip Details', Icons.list),
            const SizedBox(height: 16),
            ..._trips.asMap().entries.map((entry) {
              final index = entry.key;
              final trip = entry.value;
              return _buildTripCard(trip, index);
            }).toList(),
          ],
        ),
      ),
    );
  }
  
  Widget _buildTripCard(Trip trip, int index) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.grey.withOpacity(0.05),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey.withOpacity(0.2)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: ChoiceLuxTheme.richGold,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Text(
                    'Trip ${index + 1}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: ChoiceLuxTheme.richGold.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: ChoiceLuxTheme.richGold.withOpacity(0.3)),
                  ),
                  child: Text(
                    'R${(trip.amount ?? 0.0).toStringAsFixed(2)}',
                    style: TextStyle(
                      color: ChoiceLuxTheme.richGold,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: const Icon(Icons.edit, size: 18),
                  onPressed: () => _showTripEditModal(trip),
                  tooltip: 'Edit Trip',
                  style: IconButton.styleFrom(
                    backgroundColor: ChoiceLuxTheme.richGold.withOpacity(0.1),
                    foregroundColor: ChoiceLuxTheme.richGold,
                    padding: const EdgeInsets.all(8),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            _buildDetailRow('Date & Time', trip.formattedDateTime ?? 'Not set', Icons.access_time),
            _buildDetailRow('Pick-up', trip.pickupLocation ?? 'Not set', Icons.location_on),
            _buildDetailRow('Drop-off', trip.dropoffLocation ?? 'Not set', Icons.location_off),
            if (trip.notes != null && trip.notes!.isNotEmpty)
              _buildDetailRow('Notes', trip.notes!, Icons.note),
          ],
        ),
      ),
    );
  }
  
     Widget _buildActionButtons() {
     final currentUser = ref.read(currentUserProfileProvider);
     final isAssignedDriver = _job?.driverId == currentUser?.id;
     final isConfirmed = _job?.isConfirmed == true || _job?.driverConfirmation == true;
     final needsConfirmation = isAssignedDriver && !isConfirmed;
     final canEdit = currentUser?.role?.toLowerCase() == 'administrator' || 
                    currentUser?.role?.toLowerCase() == 'manager';
     
     return Column(
       children: [
         Row(
           children: [
             Expanded(
               child: ElevatedButton.icon(
                 onPressed: () => context.go('/jobs'),
                 icon: const Icon(Icons.list),
                 label: const Text('Back to Jobs'),
                 style: ElevatedButton.styleFrom(
                   backgroundColor: Colors.grey,
                   foregroundColor: Colors.white,
                   padding: const EdgeInsets.symmetric(vertical: 16),
                   shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                 ),
               ),
             ),
             if (needsConfirmation) ...[
               const SizedBox(width: 16),
               Expanded(
                 child: ElevatedButton.icon(
                   onPressed: _isConfirming ? null : _confirmJob,
                   icon: _isConfirming 
                       ? const SizedBox(
                           width: 16,
                           height: 16,
                           child: CircularProgressIndicator(
                             strokeWidth: 2,
                             valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                           ),
                         )
                       : const Icon(Icons.check_circle),
                   label: Text(_isConfirming ? 'Confirming...' : 'Confirm Job'),
                   style: ElevatedButton.styleFrom(
                     backgroundColor: Colors.green,
                     foregroundColor: Colors.white,
                     padding: const EdgeInsets.symmetric(vertical: 16),
                     shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                   ),
                 ),
               ),
             ] else if (canEdit) ...[
               const SizedBox(width: 16),
               Expanded(
                 child: ElevatedButton.icon(
                   onPressed: () => context.go('/jobs/${widget.jobId}/edit'),
                   icon: const Icon(Icons.edit),
                   label: const Text('Edit Job'),
                   style: ElevatedButton.styleFrom(
                     backgroundColor: ChoiceLuxTheme.richGold,
                     foregroundColor: Colors.white,
                     padding: const EdgeInsets.symmetric(vertical: 16),
                     shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                   ),
                 ),
               ),
             ],
           ],
         ),
         // Add Another Trip Button
         if (canEdit) ...[
           const SizedBox(height: 12),
           SizedBox(
             width: double.infinity,
             child: ElevatedButton.icon(
               onPressed: _showAddTripModal,
               icon: const Icon(Icons.add),
               label: const Text('Add Another Trip'),
               style: ElevatedButton.styleFrom(
                 backgroundColor: ChoiceLuxTheme.infoColor,
                 foregroundColor: Colors.white,
                 padding: const EdgeInsets.symmetric(vertical: 16),
                 shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
               ),
             ),
           ),
         ],
       ],
     );
   }

   Widget _buildMobileActionButtons() {
     final currentUser = ref.read(currentUserProfileProvider);
     final isAssignedDriver = _job?.driverId == currentUser?.id;
     final isConfirmed = _job?.isConfirmed == true || _job?.driverConfirmation == true;
     final needsConfirmation = isAssignedDriver && !isConfirmed;
     final canEdit = currentUser?.role?.toLowerCase() == 'administrator' || 
                    currentUser?.role?.toLowerCase() == 'manager';
     
     return Column(
       children: [
         SizedBox(
           width: double.infinity,
           child: ElevatedButton.icon(
             onPressed: () => context.go('/jobs'),
             icon: const Icon(Icons.list),
             label: const Text('Back to Jobs'),
             style: ElevatedButton.styleFrom(
               backgroundColor: Colors.grey,
               foregroundColor: Colors.white,
               padding: const EdgeInsets.symmetric(vertical: 16),
               shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
             ),
           ),
         ),
         if (needsConfirmation) ...[
           const SizedBox(height: 12),
           SizedBox(
             width: double.infinity,
             child: ElevatedButton.icon(
               onPressed: _isConfirming ? null : _confirmJob,
               icon: _isConfirming 
                   ? const SizedBox(
                       width: 16,
                       height: 16,
                       child: CircularProgressIndicator(
                         strokeWidth: 2,
                         valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                       ),
                     )
                   : const Icon(Icons.check_circle),
               label: Text(_isConfirming ? 'Confirming...' : 'Confirm Job'),
               style: ElevatedButton.styleFrom(
                 backgroundColor: Colors.green,
                 foregroundColor: Colors.white,
                 padding: const EdgeInsets.symmetric(vertical: 16),
                 shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
               ),
             ),
           ),
         ] else if (canEdit) ...[
           const SizedBox(height: 12),
           SizedBox(
             width: double.infinity,
             child: ElevatedButton.icon(
               onPressed: () => context.go('/jobs/${widget.jobId}/edit'),
               icon: const Icon(Icons.edit),
               label: const Text('Edit Job'),
               style: ElevatedButton.styleFrom(
                 backgroundColor: ChoiceLuxTheme.richGold,
                 foregroundColor: Colors.white,
                 padding: const EdgeInsets.symmetric(vertical: 16),
                 shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
               ),
             ),
           ),
         ],
       ],
     );
   }

  Future<void> _confirmJob() async {
    print('=== JOB SUMMARY SCREEN: _confirmJob() called ===');
    print('Job ID: ${_job!.id}');
    print('Job Status: ${_job!.status}');
    print('Is Confirmed: ${_job!.isConfirmed}');
    print('Driver Confirmation: ${_job!.driverConfirmation}');
    
    // Prevent duplicate calls
    if (_isConfirming) {
      print('Job confirmation already in progress, skipping duplicate call');
      return;
    }
    
    setState(() => _isConfirming = true);
    
    try {
      // Show loading state
      if (!mounted) {
        print('Widget not mounted, returning early');
        return;
      }
      
      print('Calling jobsProvider.confirmJob...');
      // Confirm the job using the single source of truth
      await ref.read(jobsProvider.notifier).confirmJob(_job!.id.toString(), ref: ref as WidgetRef);
      print('jobsProvider.confirmJob completed successfully');
      
      // Refresh all jobs to help with state synchronization
      await ref.read(jobsProvider.notifier).fetchJobs();
      print('Jobs list refreshed after confirmation');
      
      // Check if widget is still mounted before showing success message and navigating
      if (!mounted) {
        print('Widget not mounted after confirmation, returning early');
        return;
      }
      
      print('Showing success message...');
      // Show success message
      SnackBarUtils.showSuccess(context, '✅ Job confirmed successfully!');
      
      print('Waiting 500ms before navigation...');
      // Wait a moment for the SnackBar to show, then navigate
      await Future.delayed(const Duration(milliseconds: 500));
      
      // Check again if widget is still mounted before navigating
      if (!mounted) {
        print('Widget not mounted before navigation, returning early');
        return;
      }
      
      print('Navigating to /jobs...');
      // Navigate back to jobs management after confirmation
      context.go('/jobs');
      print('Navigation completed');
      
    } catch (e) {
      print('Error in _confirmJob: $e');
      // Check if widget is still mounted before showing error
      if (!mounted) {
        print('Widget not mounted for error display, returning early');
        return;
      }
      
      SnackBarUtils.showError(context, '❌ Failed to confirm job: $e');
    } finally {
      if (mounted) {
        setState(() => _isConfirming = false);
      }
    }
  }

  Widget _buildSectionHeader(String title, IconData icon) {
    return Row(
      children: [
        Icon(icon, color: ChoiceLuxTheme.richGold, size: 20),
        const SizedBox(width: 8),
        Text(
          title,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: ChoiceLuxTheme.richGold,
          ),
        ),
      ],
    );
  }
  
  Widget _buildDetailRow(String label, String value, IconData icon) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 16, color: Colors.grey),
          const SizedBox(width: 8),
          SizedBox(
            width: 120,
            child: Text(
              '$label:',
              style: const TextStyle(
                fontWeight: FontWeight.w500,
                color: Colors.grey,
                fontSize: 14,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  Color _getStatusColor() {
    switch (_job!.status) {
      case 'assigned':
        return ChoiceLuxTheme.richGold;
      case 'started':
        return Colors.orange;
      case 'in_progress':
        return Colors.blue;
      case 'ready_to_close':
        return Colors.purple;
      case 'completed':
        return ChoiceLuxTheme.successColor;
      case 'cancelled':
        return ChoiceLuxTheme.errorColor;
      default:
        return ChoiceLuxTheme.platinumSilver;
    }
  }
  
  String _getStatusText(String status) {
    switch (status) {
      case 'assigned':
        return 'ASSIGNED';
      case 'started':
        return 'STARTED';
      case 'in_progress':
        return 'IN PROGRESS';
      case 'ready_to_close':
        return 'READY TO CLOSE';
      case 'completed':
        return 'COMPLETED';
      case 'cancelled':
        return 'CANCELLED';
      default:
        return status.toUpperCase();
    }
  }
  
  String _formatDate(DateTime date) {
    final months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    return '${date.day.toString().padLeft(2, '0')} ${months[date.month - 1]} ${date.year}';
  }
  
  String _formatPassengerCount(dynamic count) {
    final intCount = int.tryParse(count.toString()) ?? 0;
    return '$intCount Passenger${intCount == 1 ? '' : 's'}';
  }
  
  String _formatLuggageCount(dynamic count) {
    final intCount = int.tryParse(count.toString()) ?? 0;
    return '$intCount Bag${intCount == 1 ? '' : 's'}';
  }

  String _formatDateTime(String? dateTimeString) {
    if (dateTimeString == null) return 'Not completed';
    
    try {
      final dateTime = DateTime.parse(dateTimeString);
      return '${dateTime.day}/${dateTime.month}/${dateTime.year} at ${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
    } catch (e) {
      return 'Invalid date';
    }
  }

  Future<List<Map<String, dynamic>>> _getStepTimeline() async {
    final steps = <Map<String, dynamic>>[];
    
    // Get odometer readings
    final startOdo = _driverFlowData?['odo_start_reading'] ?? 0.0;
    final endOdo = _driverFlowData?['job_closed_odo'] ?? 0.0;
    final totalKm = endOdo - startOdo;
    final progressPercentage = _driverFlowData?['progress_percentage'] ?? 0.0;
    
    // Define all possible steps in order
    final allSteps = [
      'vehicle_collection',
      'pickup_arrival', 
      'passenger_onboard',
      'dropoff_arrival',
      'trip_complete',
      'vehicle_return'
    ];
    
    // Get current step from driver flow data
    final currentStepId = _driverFlowData?['current_step']?.toString();
    
    // Load job addresses for pickup/dropoff steps
    Map<String, String?> jobAddresses = {};
    try {
      jobAddresses = await DriverFlowApiService.getJobAddresses(int.parse(widget.jobId));
    } catch (e) {
      print('Could not load job addresses: $e');
    }
    
    // Process each step
    for (final stepId in allSteps) {
      final stepTitle = DriverFlowUtils.getStepTitle(stepId);
      final stepDescription = DriverFlowUtils.getStepDescription(stepId);
      final stepIcon = DriverFlowUtils.getStepIcon(stepId);
      
      // Determine step status
      bool isCompleted = false;
      bool isCurrent = false;
      DateTime? completedAt;
      
      // Check if this is the current step
      if (currentStepId != null && currentStepId.isNotEmpty) {
        isCurrent = stepId == currentStepId;
      } else {
        // No current step means job hasn't started - first step (vehicle_collection) is current
        isCurrent = stepId == 'vehicle_collection';
      }
      
      // Check completion status for each step
      switch (stepId) {
        case 'vehicle_collection':
          isCompleted = _driverFlowData?['vehicle_collected'] == true;
          completedAt = _driverFlowData?['vehicle_collected_at'];
          break;
        case 'pickup_arrival':
          isCompleted = _tripProgressData.isNotEmpty && 
                       _tripProgressData.first['pickup_arrived_at'] != null;
          completedAt = _tripProgressData.isNotEmpty ? 
                       _tripProgressData.first['pickup_arrived_at'] : null;
          break;
        case 'passenger_onboard':
          isCompleted = _tripProgressData.isNotEmpty && 
                       _tripProgressData.first['passenger_onboard_at'] != null;
          completedAt = _tripProgressData.isNotEmpty ? 
                       _tripProgressData.first['passenger_onboard_at'] : null;
          break;
        case 'dropoff_arrival':
          isCompleted = _tripProgressData.isNotEmpty && 
                       _tripProgressData.first['dropoff_arrived_at'] != null;
          completedAt = _tripProgressData.isNotEmpty ? 
                       _tripProgressData.first['dropoff_arrived_at'] : null;
          break;
        case 'trip_complete':
          isCompleted = _tripProgressData.isNotEmpty && 
                       _tripProgressData.first['status'] == 'completed';
          completedAt = _tripProgressData.isNotEmpty ? 
                       _tripProgressData.first['updated_at'] : null;
          break;
        case 'vehicle_return':
          isCompleted = _driverFlowData?['job_closed_time'] != null;
          completedAt = _driverFlowData?['job_closed_time'];
          break;
      }
      
      // Add step to timeline with appropriate styling
      if (isCompleted) {
        // Completed step
        final stepData = {
          'title': stepTitle,
          'description': stepDescription,
          'completedAt': completedAt,
          'icon': stepIcon,
          'color': ChoiceLuxTheme.successColor,
          'status': 'completed',
        };
        
        // Add odometer info for vehicle steps
        if (stepId == 'vehicle_collection' && startOdo > 0) {
          stepData['odometer'] = 'Start: ${startOdo.toStringAsFixed(1)} km';
        } else if (stepId == 'vehicle_return' && endOdo > 0) {
          stepData['odometer'] = 'End: ${endOdo.toStringAsFixed(1)} km';
        }
        
        steps.add(stepData);
      } else if (isCurrent) {
        // Current step
        final stepData = {
          'title': DriverFlowUtils.getStepTitleWithAddress(stepId, jobAddresses['pickup']),
          'description': stepDescription,
          'completedAt': null,
          'icon': stepIcon,
          'color': currentStepId == null ? ChoiceLuxTheme.infoColor : ChoiceLuxTheme.richGold,
          'status': currentStepId == null ? 'not_started' : 'current',
          'progressPercentage': progressPercentage,
        };
        
        // Add address info for location steps
        if (stepId == 'pickup_arrival' && jobAddresses['pickup'] != null) {
          stepData['address'] = jobAddresses['pickup'];
        } else if (stepId == 'dropoff_arrival' && jobAddresses['dropoff'] != null) {
          stepData['address'] = jobAddresses['dropoff'];
        }
        
        steps.add(stepData);
      } else {
        // Upcoming step
        final stepData = {
          'title': DriverFlowUtils.getStepTitleWithAddress(stepId, jobAddresses['pickup']),
          'description': stepDescription,
          'completedAt': null,
          'icon': stepIcon,
          'color': Colors.grey,
          'status': 'upcoming',
        };
        
        // Add address info for location steps
        if (stepId == 'pickup_arrival' && jobAddresses['pickup'] != null) {
          stepData['address'] = jobAddresses['pickup'];
        } else if (stepId == 'dropoff_arrival' && jobAddresses['dropoff'] != null) {
          stepData['address'] = jobAddresses['dropoff'];
        }
        
        steps.add(stepData);
      }
    }
    
    // Add total kilometers traveled if job is completed
    final vehicleReturnedAt = _driverFlowData?['job_closed_time'];
    if (startOdo > 0 && endOdo > 0 && totalKm > 0 && vehicleReturnedAt != null) {
      steps.add({
        'title': 'Total Distance Traveled',
        'description': 'Total kilometers covered during this job',
        'completedAt': null,
        'icon': Icons.speed,
        'color': Colors.indigo,
        'odometer': 'Total: ${totalKm.toStringAsFixed(1)} km',
        'status': 'completed',
        'isTotal': true,
      });
    }
    
    return steps;
  }
  
  void _printJobSummary() {
    // TODO: Implement print functionality
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Print functionality coming soon')),
    );
  }
  
  void _shareJobSummary() {
    // TODO: Implement share functionality
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Share functionality coming soon')),
    );
  }

  void _showTripEditModal(Trip trip) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Trip'),
        content: const Text('Trip editing functionality is not yet implemented.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _showAddTripModal() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add Trip'),
        content: const Text('Trip creation functionality is not yet implemented.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }
} 