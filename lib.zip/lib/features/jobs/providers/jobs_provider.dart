import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:developer' as developer;
import '../models/job.dart';
import '../models/trip.dart';
import '../services/driver_flow_api_service.dart';
import 'package:choice_lux_cars/core/services/supabase_service.dart';
import 'package:choice_lux_cars/features/auth/providers/auth_provider.dart';
import 'package:choice_lux_cars/features/notifications/providers/notification_provider.dart';
import 'package:choice_lux_cars/core/constants/notification_constants.dart';
import 'package:uuid/uuid.dart';
import '../services/job_assignment_service.dart';
import 'package:choice_lux_cars/shared/utils/sa_time_utils.dart';

enum UserRole { administrator, manager, driverManager, driver, unknown }

// Global job update notifier for cross-user state synchronization
final jobUpdateNotifier = StateNotifierProvider<JobUpdateNotifier, String?>((ref) {
  return JobUpdateNotifier();
});

class JobUpdateNotifier extends StateNotifier<String?> {
  JobUpdateNotifier() : super(null);
  
  void notifyJobUpdate(String jobId) {
    state = jobId;
  }
}

final Ref ref;

final jobsProvider = StateNotifierProvider<JobsNotifier, AsyncValue<List<Job>>>((ref) {
  final currentUser = ref.watch(currentUserProfileProvider);
  final notifier = JobsNotifier(ref, currentUser);
  
  // Watch for user changes and update the notifier
  ref.listen(currentUserProfileProvider, (previous, next) {
    if (previous?.id != next?.id) {
      developer.log('User changed from ${previous?.id} to ${next?.id}, updating jobs provider');
      notifier.updateUser(next);
    }
  });
  
  return notifier;
});

final tripsProvider = StateNotifierProvider.family<TripsNotifier, List<Trip>, int>((ref, jobId) => TripsNotifier(jobId));

class JobsNotifier extends StateNotifier<AsyncValue<List<Job>>> {
  final Ref ref;
  dynamic currentUser;
  bool _isConfirming = false; // Prevent duplicate confirmation calls
  
  JobsNotifier(this.ref, this.currentUser) : super(const AsyncValue.loading()) {
    fetchJobs();
  }

  // Update current user and refresh jobs
  void updateUser(dynamic newUser) {
    currentUser = newUser;
    fetchJobs();
  }

  // Fetch jobs based on user role
  Future<void> fetchJobs() async {
    try {
      state = const AsyncValue.loading();
      developer.log('=== FETCHING JOBS ===');
      developer.log('Current user: ${currentUser?.id} (${currentUser?.role})');
      
      List<Map<String, dynamic>> jobMaps;
      
      if (currentUser == null) {
        developer.log('No current user, setting empty state');
        state = const AsyncValue.data([]);
        return;
      }

      final userRole = currentUser.role?.toLowerCase();
      final userId = currentUser.id;

      if (userRole == 'administrator' || userRole == 'manager') {
        // Admins and managers see all jobs
        developer.log('Fetching all jobs for admin/manager');
        jobMaps = await SupabaseService.instance.getJobs();
      } else if (userRole == 'driver_manager') {
        // Driver managers see jobs they created or are assigned to them
        developer.log('Fetching jobs for driver manager: $userId');
        jobMaps = await SupabaseService.instance.getJobsByDriverManager(userId);
      } else if (userRole == 'driver') {
        // Drivers see only jobs assigned to them
        developer.log('Fetching jobs for driver: $userId');
        jobMaps = await SupabaseService.instance.getJobsByDriver(userId);
      } else {
        // Other roles see no jobs
        developer.log('Unknown role: $userRole, setting empty state');
        if (!mounted) return;
        state = const AsyncValue.data([]);
        return;
      }

      developer.log('Fetched ${jobMaps.length} jobs');
      if (jobMaps.isNotEmpty) {
        developer.log('Sample job: ${jobMaps.first}');
      }

      if (!mounted) return;
      state = AsyncValue.data(jobMaps.map((map) => Job.fromMap(map)).toList());
      developer.log('State updated with ${state.data?.length ?? 0} jobs');
    } catch (error) {
      developer.log('Error fetching jobs: $error');
      if (!mounted) return;
      state = const AsyncValue.data([]);
    }
  }

  // Get open jobs only
  List<Job> get openJobs => state.maybeWhen(
    data: (jobsList) => jobsList.where((job) => job.isOpen).toList(),
    orElse: () => [],
  );

  // Get closed jobs only
  List<Job> get closedJobs => state.maybeWhen(
    data: (jobsList) => jobsList.where((job) => job.isClosed).toList(),
    orElse: () => [],
  );

  // Get in-progress jobs only
  List<Job> get inProgressJobs => state.maybeWhen(
    data: (jobsList) => jobsList.where((job) => job.isInProgress).toList(),
    orElse: () => [],
  );

  // Check if current user can create jobs
  bool get canCreateJobs {
    if (currentUser == null) return false;
    final userRole = currentUser.role?.toLowerCase();
    return userRole == 'administrator' || 
           userRole == 'admin' ||
           userRole == 'manager' ||
           userRole == 'driver_manager' ||
           userRole == 'drivermanager';
  }

  // Get jobs by status
  List<Job> getJobsByStatus(String status) {
    switch (status.toLowerCase()) {
      case 'open':
        return openJobs;
      case 'in_progress':
        return inProgressJobs;
      case 'completed':
        return closedJobs;
      case 'all':
        return state.data ?? [];
      default:
        return state.data ?? [];
    }
  }

  // Create new job
  Future<Map<String, dynamic>> createJob(Job job) async {
    try {
      developer.log('=== CREATING JOB ===');
      developer.log('Job data: ${job.toMap()}');
      
      final createdJob = await SupabaseService.instance.createJob(job.toMap());
      developer.log('Job created successfully: $createdJob');
      
      // If job has a driver assigned, create notification automatically
      if (job.driverId != null && job.driverId!.isNotEmpty) {
        try {
          developer.log('Job has driver assigned, creating notification...');
          await JobAssignmentService.assignJobToDriver(
            jobId: createdJob['id'] as int,
            driverId: job.driverId!,
            isReassignment: false,
          );
          developer.log('Notification created for job assignment');
        } catch (notificationError) {
          developer.log('Warning: ${NotificationConstants.errorNotificationCreationFailed}: $notificationError');
          // Don't fail the job creation if notification fails
          // In production, this should be logged to monitoring system
        }
      }
      
      if (mounted) {
        developer.log('Refreshing jobs list...');
        await fetchJobs();
        developer.log('Jobs list refreshed. Current state has ${state.data?.length} jobs');
      } else {
        developer.log('Provider not mounted, skipping refresh');
      }
      
      return createdJob;
    } catch (error) {
      developer.log('Error creating job: $error');
      rethrow;
    }
  }

  // Update job
  Future<void> updateJob(Job job) async {
    try {
      await SupabaseService.instance.updateJob(jobId: job.id, data: job.toMap());
      if (mounted) {
        await fetchJobs();
      }
    } catch (error) {
      developer.log('Error updating job: $error');
      rethrow;
    }
  }

  // Update job status
  Future<void> updateJobStatus(int jobId, String newStatus) async {
    try {
      await SupabaseService.instance.updateJob(
        jobId: jobId, 
        data: {
          'job_status': newStatus,
          'updated_at': SATimeUtils.getCurrentSATimeISO(),
        }
      );
      if (mounted) {
        await fetchJobs();
      }
    } catch (error) {
      developer.log('Error updating job status: $error');
      rethrow;
    }
  }

  // Refresh a specific job (useful after confirmation)
  Future<void> refreshJob(String jobId) async {
    try {
      // Fetch the specific job to get updated data
      final jobData = await SupabaseService.instance.getJob(jobId);
      if (jobData != null) {
        final updatedJob = Job.fromMap(jobData);
        
        // Update the job in the state
        final updatedJobs = state.data?.map((job) {
          if (job.id == jobId) {
            return updatedJob;
          }
          return job;
        }).toList() ?? [];
        
        if (mounted) {
          state = AsyncValue.data(updatedJobs);
        }
      }
    } catch (error) {
      developer.log('Error refreshing job: $error');
      // Fallback to full refresh
      await fetchJobs();
    }
  }

  // Update job payment amount
  Future<void> updateJobPaymentAmount(String jobId, double amount) async {
    try {
      await SupabaseService.instance.updateJob(
        jobId: jobId, 
        data: {
          'amount': amount,
          'updated_at': SATimeUtils.getCurrentSATimeISO(),
        }
      );
      if (mounted) {
        await fetchJobs();
      }
    } catch (error) {
      developer.log('Error updating job payment amount: $error');
      rethrow;
    }
  }

  // Delete job
  Future<void> deleteJob(String jobId) async {
    try {
      await SupabaseService.instance.deleteJob(jobId);
      if (mounted) {
        await fetchJobs();
      }
    } catch (error) {
      developer.log('Error deleting job: $error');
      rethrow;
    }
  }

  // Confirm job assignment - SINGLE SOURCE OF TRUTH
  Future<void> confirmJob(String jobId, {required WidgetRef ref}) async {
    developer.log('=== JOBS PROVIDER: confirmJob() called ===');
    developer.log('Job ID: $jobId');
    developer.log('Current User: ${currentUser?.id}');
    developer.log('Current User Role: ${currentUser?.role}');
    
    // Prevent duplicate calls
    if (_isConfirming) {
      developer.log('Job confirmation already in progress, skipping duplicate call');
      return;
    }
    
    _isConfirming = true;
    
    try {
      developer.log('Updating job in database...');
      await SupabaseService.instance.updateJob(
        jobId: jobId,
        data: {
          'is_confirmed': true,
          'driver_confirm_ind': true, // Backward compatibility
          'confirmed_at': SATimeUtils.getCurrentSATimeISO(),
          'confirmed_by': currentUser?.id,
          'updated_at': SATimeUtils.getCurrentSATimeISO(),
        }
      );
      
      developer.log('Job confirmation updated in database successfully');
      
      // Hide all notifications for this job (soft delete)
      try {
        developer.log('Hiding job notifications...');
        await ref.read(notificationProvider.notifier).hideJobNotifications(jobId);
        developer.log('Job notifications hidden successfully');
      } catch (e) {
        developer.log('Warning: Could not hide notifications: $e');
      }
      
      // Update the local state to reflect the confirmation
      if (mounted) {
        developer.log('Updating local state...');
        final updatedJobs = state.data?.map((job) {
          if (job.id == jobId) {
            developer.log('Found job to update: ${job.id}');
            return job.copyWith(
              isConfirmed: true,
              driverConfirmation: true,
              confirmedAt: DateTime.now(),
              confirmedBy: currentUser?.id,
            );
          }
          return job;
        }).toList() ?? [];
        
        state = AsyncValue.data(updatedJobs);
        developer.log('Local state updated after confirmation');
        
        // Trigger global update notification for other users
        ref.read(jobUpdateNotifier.notifier).notifyJobUpdate(jobId);
        developer.log('Global job update notification sent');
      } else {
        developer.log('Provider not mounted, skipping local state update');
      }
      
      developer.log('=== JOB CONFIRMATION COMPLETED SUCCESSFULLY ===');
    } catch (error) {
      developer.log('Error confirming job: $error');
      rethrow;
    } finally {
      _isConfirming = false;
    }
  }

  // Get jobs that need confirmation (for current driver)
  List<Job> get jobsNeedingConfirmation {
    if (currentUser == null) return [];
    
    return state.data?.where((job) => 
      job.driverId == currentUser!.id && 
      job.driverConfirmation != true
    ).toList() ?? [];
  }

  // Get confirmation status for a specific job
  bool isJobConfirmed(String jobId) {
    try {
      final job = state.data?.firstWhere((j) => j.id == jobId);
      return job?.isConfirmed == true || job?.driverConfirmation == true;
    } catch (e) {
      return false;
    }
  }

  // Fetch a single job by ID
  Future<Job?> fetchJobById(String jobId) async {
    try {
      final jobMap = await SupabaseService.instance.getJob(jobId);
      if (jobMap != null) {
        return Job.fromMap(jobMap);
      }
      return null;
    } catch (error) {
      developer.log('Error fetching job by ID: $error');
      return null;
    }
  }

  // Public method to refresh jobs list (useful for external components)
  Future<void> refreshJobs() async {
    if (mounted) {
      await fetchJobs();
    }
  }

  // Handle job starting - updates job status and refreshes list
  Future<void> startJob(String jobId, {
    required double odoStartReading,
    required String pdpStartImage,
    required double gpsLat,
    required double gpsLng,
    double? gpsAccuracy,
  }) async {
    try {
      // Call the driver flow API to start the job
      await DriverFlowApiService.startJob(
        int.parse(jobId),
        odoStartReading: odoStartReading,
        pdpStartImage: pdpStartImage,
        gpsLat: gpsLat,
        gpsLng: gpsLng,
        gpsAccuracy: gpsAccuracy,
      );
      
      // Refresh jobs list after job is started
      if (mounted) {
        fetchJobs();
      }
    } catch (error) {
      developer.log('Error starting job: $error');
      rethrow;
    }
  }

  // Manually trigger job assignment notification (for testing)
  Future<void> triggerJobAssignmentNotification(int jobId, String driverId) async {
    try {
      developer.log('=== MANUALLY TRIGGERING JOB ASSIGNMENT NOTIFICATION ===');
      developer.log('Job ID: $jobId');
      developer.log('Driver ID: $driverId');
      
      await JobAssignmentService.assignJobToDriver(
        jobId: jobId,
        driverId: driverId,
        isReassignment: false,
      );
      
      developer.log('Job assignment notification triggered successfully');
    } catch (error) {
      developer.log('Error triggering job assignment notification: $error');
      rethrow;
    }
  }
}

class TripsNotifier extends StateNotifier<List<Trip>> {
  final int jobId;

  TripsNotifier(this.jobId) : super([]);

  // Fetch trips for a specific job
  Future<void> fetchTripsForJob(String jobId) async {
    try {
      final tripMaps = await SupabaseService.instance.getTripsByJob(jobId);
      if (!mounted) return;
      state = tripMaps.map((map) => Trip.fromMap(map)).toList();
    } catch (error) {
      developer.log('Error fetching trips: $error');
      if (!mounted) return;
      state = [];
    }
  }

  // Add trip to job
  Future<void> addTrip(Trip trip) async {
    try {
      await SupabaseService.instance.createTrip(trip.toMap());
      await fetchTripsForJob(trip.jobId);
    } catch (error) {
      developer.log('Error adding trip: $error');
      rethrow;
    }
  }

  // Update trip
  Future<void> updateTrip(Trip trip) async {
    try {
      await SupabaseService.instance.updateTrip(
        tripId: trip.id, 
        data: trip.toMap()
      );
      await fetchTripsForJob(trip.jobId);
    } catch (error) {
      developer.log('Error updating trip: $error');
      rethrow;
    }
  }

  // Delete trip
  Future<void> deleteTrip(String tripId, String jobId) async {
    try {
      await SupabaseService.instance.deleteTrip(tripId);
      await fetchTripsForJob(jobId);
    } catch (error) {
      developer.log('Error deleting trip: $error');
      rethrow;
    }
  }

  // Clear trips (for new job creation)
  void clearTrips() {
    state = [];
  }

  // Get total amount for all trips
  double get totalAmount => state.fold(0, (sum, trip) => sum + trip.amount);
} 